extends Node3D
## Fixed pool of RigidBody3D body-part debris (no per-hit allocation).
const POOL := 14
const LIFE := 8.0
var _items: Array = []
var _timers: Array = []
var _next := 0

func _ready() -> void:
	for i in POOL:
		var rb := RigidBody3D.new()
		rb.mass = 12.0
		rb.collision_layer = 4      # debris layer; collides with world only
		rb.collision_mask = 1
		var cs := CollisionShape3D.new()
		cs.shape = BoxShape3D.new()
		rb.add_child(cs)
		var mi := MeshInstance3D.new()
		mi.mesh = BoxMesh.new()
		mi.material_override = StandardMaterial3D.new()
		rb.add_child(mi)
		rb.freeze = true
		rb.visible = false
		add_child(rb)
		_items.append(rb)
		_timers.append(0.0)

func spawn_piece(xf: Transform3D, size: Vector3, color: Color, inherit_vel: Vector3) -> void:
	var s := Vector3(maxf(size.x, 0.05), maxf(size.y, 0.05), maxf(size.z, 0.05))
	var rb: RigidBody3D = _items[_next]
	var idx := _next
	_next = (_next + 1) % POOL
	rb.freeze = true
	rb.global_transform = Transform3D(xf.basis.orthonormalized(), xf.origin)
	((rb.get_child(0) as CollisionShape3D).shape as BoxShape3D).size = s
	var mi: MeshInstance3D = rb.get_child(1)
	(mi.mesh as BoxMesh).size = s
	(mi.material_override as StandardMaterial3D).albedo_color = color
	rb.visible = true
	rb.freeze = false
	rb.linear_velocity = inherit_vel * 0.8 + Vector3(randf_range(-3, 3), randf_range(2, 6), randf_range(-3, 3))
	rb.angular_velocity = Vector3(randf_range(-6, 6), randf_range(-6, 6), randf_range(-6, 6))
	_timers[idx] = LIFE

func _physics_process(delta: float) -> void:
	for i in POOL:
		if _timers[i] > 0.0:
			_timers[i] -= delta
			if _timers[i] <= 0.0:
				var rb: RigidBody3D = _items[i]
				rb.freeze = true
				rb.visible = false
				rb.global_position = Vector3(0, -50, 0)

func clear_all() -> void:
	for i in POOL:
		_timers[i] = 0.0
		(_items[i] as RigidBody3D).freeze = true
		(_items[i] as RigidBody3D).visible = false
