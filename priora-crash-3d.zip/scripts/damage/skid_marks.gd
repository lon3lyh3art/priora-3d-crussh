extends Node3D
## Ring buffer of flat quads (oldest mark is recycled): bounded memory, no per-mark allocation.
const COUNT := 120
var _quads: Array = []
var _next := 0

func _ready() -> void:
	var qm := QuadMesh.new()
	qm.size = Vector2(0.2, 0.6)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.05, 0.05, 0.05)
	qm.material = mat
	for i in COUNT:
		var mi := MeshInstance3D.new()
		mi.mesh = qm
		mi.top_level = true
		mi.visible = false
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(mi)
		_quads.append(mi)

func add_mark(pos: Vector3, forward: Vector3, normal: Vector3) -> void:
	var mi: MeshInstance3D = _quads[_next]
	_next = (_next + 1) % COUNT
	var z := -forward.normalized()       # quad faces +Z, we lay it down along `forward`
	var y := normal.normalized()
	var x := y.cross(z).normalized()
	z = x.cross(y).normalized()
	# QuadMesh normal is +Z: rotate so +Z -> surface normal, quad Y -> forward
	var b := Basis(x, -z, y)
	mi.global_transform = Transform3D(b.orthonormalized(), pos + normal * 0.02)
	mi.visible = true

func clear_all() -> void:
	for q in _quads:
		q.visible = false
