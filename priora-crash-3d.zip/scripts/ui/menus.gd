extends Control
## Pause / garage / challenges / settings menus (built in code). Runs while the tree is paused.
signal closed
signal car_selected(id: String)
signal challenge_selected(id: String)
signal quality_changed(q: int)
signal debug_toggled(on: bool)

var specs: Dictionary = {}
var car_order: Array = []
var current_car := ""
var challenges = null
var _box: VBoxContainer

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var th := Theme.new()
	th.default_font_size = 22
	theme = th
	var dim := ColorRect.new()
	dim.color = Color(0.02, 0.04, 0.08, 0.92)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var scroll := ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(scroll)
	var center := CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.size_flags_vertical = Control.SIZE_EXPAND_FILL
	center.custom_minimum_size = Vector2(1280, 720)
	scroll.add_child(center)
	_box = VBoxContainer.new()
	_box.custom_minimum_size = Vector2(620, 0)
	_box.add_theme_constant_override("separation", 10)
	center.add_child(_box)
	get_viewport().size_changed.connect(_fit)
	_fit()

func _fit() -> void:
	var m := Settings.safe_margins(get_viewport_rect().size)
	offset_left = m.x
	offset_top = m.y
	offset_right = -m.z
	offset_bottom = -m.w

func _clear() -> void:
	for c in _box.get_children():
		c.queue_free()
		_box.remove_child(c)

func _title(t: String) -> void:
	var l := Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 34)
	l.add_theme_color_override("font_color", Color(1.0, 0.84, 0.43))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_box.add_child(l)

func _btn(t: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = t
	b.custom_minimum_size = Vector2(0, 64)
	b.pressed.connect(cb)
	_box.add_child(b)
	return b

func open(page := "pause") -> void:
	visible = true
	_clear()
	match page:
		"garage": _page_garage()
		"challenges": _page_challenges()
		_: _page_pause()

func close() -> void:
	visible = false
	Settings.save()
	closed.emit()

func _page_pause() -> void:
	_title("ПАУЗА")
	_btn("Продолжить", close)
	_btn("Гараж", func(): open("garage"))
	_btn("Испытания", func(): open("challenges"))
	_btn("Графика: " + ["низкая", "средняя", "высокая"][Settings.quality], func():
		Settings.quality = (Settings.quality + 1) % 3
		quality_changed.emit(Settings.quality)
		open("pause"))
	_btn("Отладка физики (F3): " + ("вкл" if Settings.debug else "выкл"), func():
		Settings.debug = not Settings.debug
		debug_toggled.emit(Settings.debug)
		open("pause"))
	var l := Label.new()
	l.text = "Чувствительность руля: %.1f" % Settings.steer_sensitivity
	_box.add_child(l)
	var sl := HSlider.new()
	sl.min_value = 0.5
	sl.max_value = 2.0
	sl.step = 0.1
	sl.value = Settings.steer_sensitivity
	sl.custom_minimum_size = Vector2(0, 40)
	sl.value_changed.connect(func(v: float):
		Settings.steer_sensitivity = v
		l.text = "Чувствительность руля: %.1f" % v)
	_box.add_child(sl)

func _page_garage() -> void:
	_title("ГАРАЖ")
	for id in car_order:
		var s = specs[id]
		var t := "%s%s\n%d кг · %d кВт · %s · макс. %d км/ч" % ["▶ " if id == current_car else "", s.display_name, int(s.mass), int(s.power_kw), s.drive_name(), int(s.top_speed_kmh)]
		var b := _btn(t, func(): car_selected.emit(id))
		b.custom_minimum_size = Vector2(0, 84)
	_btn("Назад", func(): open("pause"))

func _page_challenges() -> void:
	_title("ИСПЫТАНИЯ")
	for id in challenges.ORDER:
		_btn(challenges.DEFS[id]["name"] + challenges.record_text(id), func(): challenge_selected.emit(id))
	_btn("Назад", func(): open("pause"))
