extends Control
## Multitouch on-screen controls. Each finger index is tracked separately, so throttle and
## steering work at the same time. Touch cancel, focus loss and pause release every button.
const HOLD := ["left", "right", "gas", "brake", "hand"]
const TAP := ["reset", "cam", "pause"]
var rects := {}
var fingers := {}     # finger index -> button name

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = DisplayServer.is_touchscreen_available() or OS.get_cmdline_user_args().has("--touch")
	get_viewport().size_changed.connect(_layout)
	Inp.released_all.connect(_clear)
	_layout()

func _notification(what: int) -> void:
	if what == NOTIFICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_clear()

func _clear() -> void:
	fingers.clear()
	for b in HOLD:
		Inp.set_button(b, false)
	queue_redraw()

func _layout() -> void:
	var vp := get_viewport_rect().size
	var m := Settings.safe_margins(vp)
	var s := clampf(minf(vp.x, vp.y) * 0.19, 70.0, 140.0)
	var pad := s * 0.18
	var by := vp.y - m.w - pad - s
	rects["left"] = Rect2(m.x + pad, by, s, s)
	rects["right"] = Rect2(m.x + pad * 2.0 + s, by, s, s)
	rects["gas"] = Rect2(vp.x - m.z - pad - s * 1.2, vp.y - m.w - pad - s * 1.2, s * 1.2, s * 1.2)
	var bx := vp.x - m.z - pad * 2.0 - s * 2.2
	rects["brake"] = Rect2(bx, by, s, s)
	rects["hand"] = Rect2(bx, by - pad - s * 0.8, s, s * 0.8)
	var ts := s * 0.6
	var ty := m.y + pad
	rects["pause"] = Rect2(vp.x - m.z - pad - ts, ty, ts, ts)
	rects["reset"] = Rect2(vp.x - m.z - pad * 2.0 - ts * 2.0, ty, ts, ts)
	rects["cam"] = Rect2(vp.x - m.z - pad * 3.0 - ts * 3.0, ty, ts, ts)
	queue_redraw()

func _hit(pos: Vector2) -> String:
	for k in rects.keys():
		if (rects[k] as Rect2).grow(10.0).has_point(pos):
			return k
	return ""

func _press(idx: int, pos: Vector2) -> void:
	var nm := _hit(pos)
	if nm == "":
		return
	fingers[idx] = nm
	if nm in HOLD:
		Inp.set_button(nm, true)
	else:
		Inp.trigger(nm)
	queue_redraw()

func _release(idx: int) -> void:
	if not fingers.has(idx):
		return
	var nm: String = fingers[idx]
	fingers.erase(idx)
	if nm in HOLD and not fingers.values().has(nm):
		Inp.set_button(nm, false)
	queue_redraw()

func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		if event.pressed and not event.canceled:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		var old = fingers.get(event.index, "")
		var nm := _hit(event.position)
		if old in HOLD and nm in HOLD and nm != old:      # slide between left/right etc.
			_release(event.index)
			_press(event.index, event.position)

func _draw() -> void:
	var font := ThemeDB.fallback_font
	for k in rects.keys():
		var r: Rect2 = rects[k]
		var down: bool = fingers.values().has(k)
		var c := r.get_center()
		var rad := minf(r.size.x, r.size.y) * 0.5
		draw_circle(c, rad, Color(0.5, 0.7, 1.0, 0.45) if down else Color(1, 1, 1, 0.14))
		draw_arc(c, rad, 0.0, TAU, 32, Color(1, 1, 1, 0.35), 2.0)
		var a := rad * 0.45
		var white := Color(1, 1, 1, 0.9)
		match k:
			"left": draw_colored_polygon(PackedVector2Array([c + Vector2(-a, 0), c + Vector2(a, -a), c + Vector2(a, a)]), white)
			"right": draw_colored_polygon(PackedVector2Array([c + Vector2(a, 0), c + Vector2(-a, -a), c + Vector2(-a, a)]), white)
			"gas": draw_colored_polygon(PackedVector2Array([c + Vector2(0, -a), c + Vector2(a, a), c + Vector2(-a, a)]), white)
			"brake": draw_rect(Rect2(c - Vector2(a, a), Vector2(a * 2, a * 2)), white)
			"hand": draw_string(font, c + Vector2(-rad, 8), "РУЧН.", HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, 18, white)
			"pause": draw_string(font, c + Vector2(-rad, 8), "II", HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, 22, white)
			"reset": draw_string(font, c + Vector2(-rad, 6), "СБРОС", HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, 14, white)
			"cam": draw_string(font, c + Vector2(-rad, 6), "КАМ.", HORIZONTAL_ALIGNMENT_CENTER, rad * 2.0, 14, white)
