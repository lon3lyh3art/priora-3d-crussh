extends Control
## In-game HUD. Built in code; layout respects the display safe area.
var _speed: Label
var _car: Label
var _dmg_label: Label
var _dmg_bar: ProgressBar
var _score: Label
var _chal: Label
var _toast: Label
var _debug: Label
var _toast_t := 0.0

func _mk(size: int, color := Color.WHITE) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 5)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(l)
	return l

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_speed = _mk(40, Color(0.56, 0.75, 1.0))
	_car = _mk(18, Color(1.0, 0.84, 0.43))
	_dmg_label = _mk(18, Color(1.0, 0.54, 0.54))
	_dmg_bar = ProgressBar.new()
	_dmg_bar.show_percentage = false
	_dmg_bar.custom_minimum_size = Vector2(220, 14)
	_dmg_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_dmg_bar)
	_score = _mk(26, Color(1.0, 0.84, 0.43))
	_chal = _mk(22, Color(1.0, 0.6, 0.6))
	_toast = _mk(30, Color.WHITE)
	_toast.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_debug = _mk(14, Color(0.8, 1.0, 0.8))
	get_viewport().size_changed.connect(_layout)
	_layout()

func _layout() -> void:
	var vp := get_viewport_rect().size
	var m := Settings.safe_margins(vp)
	var x := m.x + 16.0
	var y := m.y + 8.0
	_speed.position = Vector2(x, y)
	_car.position = Vector2(x, y + 52)
	_dmg_label.position = Vector2(x, y + 78)
	_dmg_bar.position = Vector2(x, y + 106)
	_score.size = Vector2(400, 36)
	_score.position = Vector2(vp.x * 0.5 - 200, y)
	_score.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_chal.size = Vector2(700, 30)
	_chal.position = Vector2(vp.x * 0.5 - 350, y + 40)
	_chal.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast.size = Vector2(800, 40)
	_toast.position = Vector2(vp.x * 0.5 - 400, vp.y * 0.3)
	_debug.position = Vector2(x, y + 130)

func refresh(speed_kmh: float, dmg_pct: float, score: int, car_name: String, chal_text: String, debug_text: String, wrecked: bool) -> void:
	_speed.text = "%d км/ч" % int(round(speed_kmh))
	_car.text = ("Машина разбита — нажмите сброс (R)" if wrecked else car_name)
	_dmg_label.text = "Повреждения: %d%%" % int(round(dmg_pct))
	_dmg_bar.value = dmg_pct
	_score.text = "Очки: %d" % score
	_chal.text = chal_text
	_debug.text = debug_text
	_debug.visible = debug_text != ""

func toast(text: String, seconds := 2.0) -> void:
	_toast.text = text
	_toast.visible = true
	_toast_t = seconds

func _process(delta: float) -> void:
	if _toast_t > 0.0:
		_toast_t -= delta
		if _toast_t <= 0.0:
			_toast.visible = false
