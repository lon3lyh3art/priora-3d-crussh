extends Node3D
## Game root: wires world, vehicle, camera, traffic, challenges, UI and scoring.
const VehicleScene = preload("res://scenes/vehicles/vehicle.tscn")
const WorldBuilder = preload("res://scripts/world/world_builder.gd")
const Traffic = preload("res://scripts/traffic/traffic.gd")
const ChaseCamera = preload("res://scripts/camera/chase_camera.gd")
const DebrisPool = preload("res://scripts/damage/debris_pool.gd")
const SkidMarks = preload("res://scripts/damage/skid_marks.gd")
const DebugDraw = preload("res://scripts/vehicles/debug_draw.gd")
const AudioFX = preload("res://scripts/audio/audio_fx.gd")
const Hud = preload("res://scripts/ui/hud.gd")
const TouchControls = preload("res://scripts/ui/touch_controls.gd")
const Menus = preload("res://scripts/ui/menus.gd")
const Challenges = preload("res://scripts/challenges/challenge_manager.gd")
const Zones = preload("res://scripts/vehicles/zones.gd")

const CAR_IDS := ["priora", "priora_hatch", "vesta", "granta", "kalina", "largus", "vaz2107", "vaz2106", "vaz2114", "niva"]
const SPAWN_POS := Vector3(3.5, 0.7, 40.0)

var specs := {}
var car_id := "priora"
var vehicle = null
var cam
var world
var traffic
var debris
var skid
var audio
var hud
var touch
var menus
var challenges
var debug_draw
var sun: DirectionalLight3D
var score := 0
var _drift_acc := 0.0
var _wrecked_toast := false

func _ready() -> void:
	for id in CAR_IDS:
		specs[id] = load("res://data/cars/%s.tres" % id)
	_build_environment()
	world = WorldBuilder.new()
	add_child(world)
	world.build(Settings.quality)
	debris = DebrisPool.new()
	add_child(debris)
	skid = SkidMarks.new()
	add_child(skid)
	traffic = Traffic.new()
	add_child(traffic)
	cam = ChaseCamera.new()
	cam.far = 650.0
	add_child(cam)
	cam.make_current()
	audio = AudioFX.new()
	add_child(audio)
	debug_draw = DebugDraw.new()
	debug_draw.visible = Settings.debug
	add_child(debug_draw)
	challenges = Challenges.new()
	add_child(challenges)
	challenges.finished.connect(_on_challenge_finished)

	var game_ui := CanvasLayer.new()
	add_child(game_ui)
	hud = Hud.new()
	game_ui.add_child(hud)
	touch = TouchControls.new()
	game_ui.add_child(touch)
	var menu_layer := CanvasLayer.new()
	menu_layer.layer = 10
	menu_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(menu_layer)
	menus = Menus.new()
	menus.specs = specs
	menus.car_order = CAR_IDS
	menus.challenges = challenges
	menu_layer.add_child(menus)
	menus.closed.connect(_on_menu_closed)
	menus.car_selected.connect(_on_car_selected)
	menus.challenge_selected.connect(_on_challenge_selected)
	menus.quality_changed.connect(apply_quality)
	menus.debug_toggled.connect(func(on: bool): debug_draw.visible = on)
	Inp.reset_pressed.connect(_on_reset)
	Inp.camera_pressed.connect(func(): cam.cycle_mode())
	Inp.pause_pressed.connect(_toggle_pause)
	Inp.debug_pressed.connect(func():
		Settings.debug = not Settings.debug
		debug_draw.visible = Settings.debug)
	apply_quality(Settings.quality)
	spawn_vehicle(car_id)

func _build_environment() -> void:
	var env := Environment.new()
	var sky := Sky.new()
	sky.sky_material = ProceduralSkyMaterial.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.6, 0.72, 0.88)
	env.fog_density = 0.0016
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -35, 0)
	sun.light_energy = 1.3
	sun.shadow_enabled = true
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_2_SPLITS
	add_child(sun)

## 0 low / 1 medium / 2 high. Trades shadows, draw distance, traffic count and particles for FPS.
func apply_quality(q: int) -> void:
	Settings.quality = q
	var vp := get_viewport()
	match q:
		0:
			sun.shadow_enabled = false
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 0.75
			cam.far = 300.0
			traffic.spawn(6)
		1:
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 70.0
			vp.msaa_3d = Viewport.MSAA_DISABLED
			vp.scaling_3d_scale = 1.0
			cam.far = 450.0
			traffic.spawn(10)
		_:
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 120.0
			vp.msaa_3d = Viewport.MSAA_2X
			vp.scaling_3d_scale = 1.0
			cam.far = 650.0
			traffic.spawn(14)
	if vehicle != null:
		vehicle.particle_scale = [0.5, 1.0, 1.5][q]

func spawn_vehicle(id: String) -> void:
	if vehicle != null:
		remove_child(vehicle)
		vehicle.queue_free()
	car_id = id
	vehicle = VehicleScene.instantiate()
	vehicle.setup(specs[id])
	vehicle.debris_pool = debris
	vehicle.skid_marks = skid
	vehicle.particle_scale = [0.5, 1.0, 1.5][Settings.quality]
	vehicle.transform = Transform3D(Basis(Vector3.UP, 0.0), SPAWN_POS)
	add_child(vehicle)
	vehicle.crashed.connect(_on_crashed)
	vehicle.landed.connect(_on_landed)
	vehicle.wrecked.connect(func(): hud.toast("Машина разбита!", 3.0))
	cam.target = vehicle
	cam.snap()
	debug_draw.vehicle = vehicle
	debris.clear_all()
	skid.clear_all()
	menus.current_car = id
	_wrecked_toast = false

# ------------------------------------------------------------- game loop
func _physics_process(delta: float) -> void:
	if vehicle == null:
		return
	vehicle.set_controls(Inp.get_throttle(), Inp.get_brake(), Inp.steer, Inp.get_handbrake())
	if vehicle.drift_angle > 0.35 and vehicle.grounded:
		_drift_acc += delta * vehicle.speed_kmh() * 0.5
	else:
		if _drift_acc > 40.0:
			_add_score(int(_drift_acc), "Дрифт")
		_drift_acc = 0.0
	challenges.tick(delta, vehicle.speed_kmh(), vehicle.damage_percent(), score)
	audio.update_engine(vehicle.linear_velocity.length(), Inp.get_throttle())
	if vehicle.global_position.y < -20.0:
		vehicle.reset_upright(not challenges.is_active())

func _process(_d: float) -> void:
	if vehicle == null:
		return
	hud.refresh(vehicle.speed_kmh(), vehicle.damage_percent(), score, specs[car_id].display_name,
		challenges.status_text(), vehicle.debug_text() if Settings.debug else "", vehicle.is_wrecked)

func _add_score(n: int, label: String) -> void:
	score += n
	hud.toast("%s +%d" % [label, n], 1.5)

func _on_crashed(zone: int, intensity: float, _pos: Vector3) -> void:
	_add_score(int(intensity * 25.0), "Удар")
	cam.add_shake(clampf(intensity * 0.03, 0.05, 0.4))
	audio.crash(intensity)

func _on_landed(air_time: float, impact: float) -> void:
	if air_time > 0.8:
		_add_score(int(air_time * 100.0), "Прыжок")
	cam.add_shake(clampf(impact * 0.02, 0.0, 0.3))

# ------------------------------------------------------------- menus / actions
func _toggle_pause() -> void:
	if menus.visible:
		menus.close()
	else:
		get_tree().paused = true
		Inp.release_all()
		menus.open("pause")

func _on_menu_closed() -> void:
	get_tree().paused = false

func _on_reset() -> void:
	if menus.visible or vehicle == null:
		return
	# during a challenge the car is repositioned but NOT repaired (no exploit in "survive")
	vehicle.reset_upright(not challenges.is_active())
	debris.clear_all()
	hud.toast("Сброс", 1.0)

func _on_car_selected(id: String) -> void:
	challenges.cancel()          # changing car aborts a running challenge without a record
	score = 0
	spawn_vehicle(id)
	menus.close()

func _on_challenge_selected(id: String) -> void:
	score = 0
	vehicle.reset_upright(true)
	debris.clear_all()
	challenges.start(id)
	menus.close()

func _on_challenge_finished(id: String, win: bool, value: float, new_record: bool, text: String) -> void:
	var v := ("%.1f с" % value) if id == "speed" else str(int(value))
	hud.toast("%s: %s" % [text, v], 4.0)

func _exit_tree() -> void:
	get_tree().paused = false
