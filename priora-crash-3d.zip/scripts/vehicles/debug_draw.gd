extends MeshInstance3D
## Debug overlay: suspension rays/contacts, tyre force vectors (F3).
var vehicle = null

func _ready() -> void:
	top_level = true
	mesh = ImmediateMesh.new()
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.no_depth_test = true
	material_override = m
	cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

func _process(_d: float) -> void:
	var im: ImmediateMesh = mesh
	im.clear_surfaces()
	if vehicle == null or not is_instance_valid(vehicle) or not visible:
		return
	var verts: Array = []
	var cols: Array = []
	var tf: Transform3D = vehicle.global_transform
	var k := 1.0 / (vehicle.spec.mass * 9.81 * 0.25)
	for w in vehicle.wheels:
		var mp: Vector3 = tf * w.mount
		var end: Vector3 = tf * (w.mount + Vector3(0, -(vehicle.spec.susp_travel + vehicle.spec.wheel_radius), 0))
		verts.append(mp); verts.append(w.point if w.contact else end)
		var c := Color(0.2, 1.0, 0.3) if w.contact else Color(1, 0.2, 0.2)
		cols.append(c); cols.append(c)
		if w.contact:
			verts.append(w.point); verts.append(w.point + w.normal * w.load_n * k)   # load (blue)
			cols.append(Color(0.3, 0.5, 1)); cols.append(Color(0.3, 0.5, 1))
			var fc := Color(1, 0.3, 0.1) if w.sliding else Color(1, 1, 0.2)
			verts.append(w.point); verts.append(w.point + w.force_vec * k)             # tyre force
			cols.append(fc); cols.append(fc)
	im.surface_begin(Mesh.PRIMITIVE_LINES)
	for i in verts.size():
		im.surface_set_color(cols[i])
		im.surface_add_vertex(verts[i])
	im.surface_end()
