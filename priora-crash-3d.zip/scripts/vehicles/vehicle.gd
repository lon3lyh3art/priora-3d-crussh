extends RigidBody3D
## Raycast-suspension car on a RigidBody3D.
## Coordinates: forward = -Z, up = +Y, right = +X. Origin = suspension mount plane.
## Each physics tick: per wheel ray -> spring/damper force along surface normal ->
## tyre force (longitudinal + lateral) limited by mu * normal load (friction circle).
## Approximation: no gearbox/engine RPM model, no tyre thermal model, no soft-body.

signal crashed(zone: int, intensity: float, world_pos: Vector3)
signal landed(air_time: float, impact: float)
signal wrecked

const Zones = preload("res://scripts/vehicles/zones.gd")
const CarVisual = preload("res://scripts/vehicles/car_visual.gd")
const GRAVITY := 9.81
const AIR_DENSITY := 1.2
const MAX_SPEED := 90.0          # m/s hard safety clamp
const HIT_THRESHOLD := 2.0       # m/s of velocity change before damage starts

class WheelState:
	var mount := Vector3.ZERO
	var front := false
	var driven := false
	var contact := false
	var point := Vector3.ZERO
	var normal := Vector3.UP
	var length := 0.0
	var prev_length := 0.0
	var compression := 0.0
	var load_n := 0.0
	var spring_k := 0.0
	var spring_c := 0.0
	var vlong := 0.0
	var vlat := 0.0
	var slip := 0.0
	var sliding := false
	var force_vec := Vector3.ZERO
	var spin := 0.0
	var node: Node3D
	var mesh_spin: Node3D
	var last_skid := Vector3(1.0e9, 0.0, 0.0)

var spec
var wheels: Array = []
var zone_damage := PackedFloat32Array()
var wheel_health := PackedFloat32Array()
var panels: Dictionary = {}
var is_wrecked := false
var air_time := 0.0
var drift_angle := 0.0
var grounded := false
var debris_pool = null
var skid_marks = null
var particle_scale := 1.0

var throttle_in := 0.0
var brake_in := 0.0
var steer_in := 0.0
var handbrake_in := false
var steer_cur := 0.0
var rear_grip_mod := 1.0
var _last_vy := 0.0
var _reset_pending := false
var _reset_xf := Transform3D.IDENTITY
var _pending_hits: Array = []
var _ray := PhysicsRayQueryParameters3D.new()
var _sparks: CPUParticles3D
var _smoke: CPUParticles3D
var _body_offset := 0.0

func setup(p_spec) -> void:
	spec = p_spec
	mass = spec.mass
	can_sleep = false
	continuous_cd = true
	contact_monitor = true
	max_contacts_reported = 8
	linear_damp = 0.0
	angular_damp = 0.6
	collision_layer = 2          # layer 2: vehicles/dynamic props (not hit by wheel rays)
	collision_mask = 3           # collide with world (1) and dynamic (2)
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = Vector3(0.0, -0.15, 0.0)
	var h := spec.height * 0.8
	inertia = Vector3(
		mass / 12.0 * (h * h + spec.length * spec.length),
		mass / 12.0 * (spec.width * spec.width + spec.length * spec.length),
		mass / 12.0 * (spec.width * spec.width + h * h))
	var pm := PhysicsMaterial.new()
	pm.friction = 0.35
	pm.bounce = 0.05
	physics_material_override = pm
	zone_damage.resize(Zones.COUNT)
	zone_damage.fill(0.0)
	wheel_health.resize(4)
	wheel_health.fill(1.0)
	_ray.collision_mask = 1
	_ray.exclude = []
	# wheels: 0 FL, 1 FR, 2 RL, 3 RR. front axle at -(1-fw)*wb, rear at +fw*wb (COM at z=0)
	var fw: float = spec.front_weight
	var zf := -(1.0 - fw) * spec.wheelbase
	var zr := fw * spec.wheelbase
	_body_offset = -(zf + zr) * 0.5
	var xs := spec.track * 0.5
	var mounts := [Vector3(-xs, 0, zf), Vector3(xs, 0, zf), Vector3(-xs, 0, zr), Vector3(xs, 0, zr)]
	for i in 4:
		var w := WheelState.new()
		w.mount = mounts[i]
		w.front = i < 2
		w.driven = (spec.drive == 2) or (spec.drive == 0 and w.front) or (spec.drive == 1 and not w.front)
		var share: float = fw if w.front else (1.0 - fw)
		var load_w: float = spec.mass * GRAVITY * share * 0.5
		w.spring_k = load_w / spec.susp_sag
		w.spring_c = 2.0 * spec.damping_ratio * sqrt(w.spring_k * (load_w / GRAVITY))
		w.length = spec.susp_travel - spec.susp_sag
		w.prev_length = w.length
		wheels.append(w)
	var vis := CarVisual.build(self, spec, wheels, _body_offset)
	panels = vis["panels"]
	_build_fx()

func _build_fx() -> void:
	_sparks = CPUParticles3D.new()
	_sparks.emitting = false
	_sparks.one_shot = true
	_sparks.amount = 18
	_sparks.lifetime = 0.45
	_sparks.explosiveness = 1.0
	_sparks.local_coords = false
	_sparks.direction = Vector3.UP
	_sparks.spread = 70.0
	_sparks.initial_velocity_min = 3.0
	_sparks.initial_velocity_max = 8.0
	_sparks.gravity = Vector3(0, -14, 0)
	var sm := BoxMesh.new()
	sm.size = Vector3(0.05, 0.05, 0.05)
	var smat := StandardMaterial3D.new()
	smat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	smat.albedo_color = Color(1.0, 0.75, 0.25)
	sm.material = smat
	_sparks.mesh = sm
	add_child(_sparks)
	_smoke = CPUParticles3D.new()
	_smoke.emitting = false
	_smoke.amount = 20
	_smoke.lifetime = 1.6
	_smoke.local_coords = false
	_smoke.direction = Vector3.UP
	_smoke.spread = 15.0
	_smoke.initial_velocity_min = 1.0
	_smoke.initial_velocity_max = 2.0
	_smoke.gravity = Vector3(0, 0.6, 0)
	_smoke.scale_amount_min = 0.8
	_smoke.scale_amount_max = 1.6
	var sph := SphereMesh.new()
	sph.radius = 0.22
	sph.height = 0.44
	sph.radial_segments = 6
	sph.rings = 3
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color = Color(0.25, 0.25, 0.25, 0.45)
	sph.material = mat
	_smoke.mesh = sph
	_smoke.position = Vector3(0, 0.45, -spec.length * 0.3)
	add_child(_smoke)

# ---------------------------------------------------------------- public API
func set_controls(throttle: float, brake: float, steer: float, handbrake: bool) -> void:
	throttle_in = clampf(throttle, 0.0, 1.0)
	brake_in = clampf(brake, 0.0, 1.0)
	steer_in = clampf(steer, -1.0, 1.0)
	handbrake_in = handbrake

func speed_kmh() -> float:
	return linear_velocity.length() * 3.6

func forward_speed() -> float:
	return linear_velocity.dot(-global_transform.basis.z)

## 0..1, 1 = wrecked.
func damage_ratio() -> float:
	var s := 0.0
	for z in Zones.COUNT:
		s += zone_damage[z] * Zones.WEIGHT[z]
	return clampf(s * 1.6, 0.0, 1.0)

func damage_percent() -> float:
	return damage_ratio() * 100.0

func reset_to(xf: Transform3D, repair_car: bool = true) -> void:
	_reset_xf = xf
	_reset_pending = true
	if repair_car:
		repair()
	for w in wheels:
		w.contact = false
		w.prev_length = w.length

func reset_upright(repair_car: bool = true) -> void:
	var pos := global_position
	var yaw := 0.0
	if _state_finite():
		yaw = global_transform.basis.get_euler().y
	else:
		pos = Vector3(0, 0, 0)
	if absf(pos.x) > 195.0 or absf(pos.z) > 995.0 or pos.y < -5.0:
		pos = Vector3(3.5, 0, 40.0)
	pos.y = maxf(pos.y, 0.0) + 0.9
	reset_to(Transform3D(Basis(Vector3.UP, yaw), pos), repair_car)

func repair() -> void:
	zone_damage.fill(0.0)
	wheel_health.fill(1.0)
	is_wrecked = false
	_smoke.emitting = false
	for z in panels.keys():
		for m in panels[z]:
			m.visible = true
			m.set_meta("detached", false)
		_update_panel(z)

func debug_text() -> String:
	var s := "v=%.1f km/h  dmg=%.0f%%  air=%.2f  drift=%.0f°\n" % [speed_kmh(), damage_percent(), air_time, rad_to_deg(drift_angle)]
	var names := ["FL", "FR", "RL", "RR"]
	for i in 4:
		var w = wheels[i]
		s += "%s %s comp=%.2f N=%5.0f slip=%.2f %s hp=%.2f\n" % [names[i], "G" if w.contact else "-", w.compression, w.load_n, w.slip, "SLIDE" if w.sliding else "grip", wheel_health[i]]
	return s

# ---------------------------------------------------------------- physics
func _state_finite() -> bool:
	var p := global_position
	var v := linear_velocity
	var a := angular_velocity
	return is_finite(p.x) and is_finite(p.y) and is_finite(p.z) \
		and is_finite(v.x) and is_finite(v.y) and is_finite(v.z) \
		and is_finite(a.x) and is_finite(a.y) and is_finite(a.z)

func _integrate_forces(state: PhysicsDirectBodyState3D) -> void:
	if _reset_pending:
		state.transform = _reset_xf
		state.linear_velocity = Vector3.ZERO
		state.angular_velocity = Vector3.ZERO
		_reset_pending = false
		return
	var spd := state.linear_velocity.length()
	if spd > MAX_SPEED:
		state.linear_velocity *= MAX_SPEED / spd
	if state.angular_velocity.length() > 25.0:
		state.angular_velocity = state.angular_velocity.normalized() * 25.0
	var inv := state.transform.affine_inverse()
	for i in state.get_contact_count():
		var dv := state.get_contact_impulse(i).length() / mass
		if dv < HIT_THRESHOLD:
			continue
		var lp: Vector3 = inv * state.get_contact_local_position(i)
		_pending_hits.append([_zone_from_local(lp), dv, lp])

func _zone_from_local(lp: Vector3) -> int:
	var hl: float = spec.length * 0.5
	var hw: float = spec.width * 0.5
	if lp.y < -0.14:
		return Zones.WHEELS
	if lp.y > 0.42:
		return Zones.ROOF
	if lp.z < -hl + 0.9:
		return Zones.FRONT if lp.y < 0.24 else Zones.HOOD
	if lp.z > hl - 0.9:
		return Zones.REAR if lp.y < 0.24 else Zones.TRUNK
	if absf(lp.x) > hw * 0.6:
		return Zones.LEFT if lp.x < 0.0 else Zones.RIGHT
	return Zones.ROOF

func _physics_process(delta: float) -> void:
	if delta <= 0.0 or spec == null:
		return
	if not _state_finite():
		push_warning("Vehicle state not finite; resetting")
		reset_upright(true)
		return
	_process_hits()
	var space := get_world_3d().direct_space_state
	var basis_g := global_transform.basis
	var down := -basis_g.y
	var up := basis_g.y
	var com_g: Vector3 = to_global(center_of_mass)
	var fwd := -basis_g.z
	var fs: float = linear_velocity.dot(fwd)

	steer_cur = move_toward(steer_cur, steer_in, 8.0 * delta)
	var speed_abs := absf(fs)
	var max_deg: float = lerpf(spec.max_steer_deg, 6.0, clampf((speed_abs - 3.0) / 30.0, 0.0, 1.0))
	var steer_angle := -steer_cur * deg_to_rad(max_deg)   # +angle = turn left about +Y
	var toe_pull: float = (wheel_health[1] - wheel_health[0]) * 0.07

	# drive / brake command logic (auto reverse)
	var drive_cmd := 0.0
	var brake_cmd := 0.0
	if throttle_in > 0.05:
		if fs < -1.0: brake_cmd = 1.0
		else: drive_cmd = throttle_in
	elif brake_in > 0.05:
		if fs > 0.5: brake_cmd = brake_in
		else: drive_cmd = -brake_in
	var health_pwr := 0.35 if is_wrecked else 1.0
	var power: float = spec.power_kw * 1000.0 * 0.85 * health_pwr
	var cap: float = spec.mass * spec.max_accel * health_pwr
	var f_avail := minf(power / maxf(speed_abs, 2.0), cap)
	if drive_cmd > 0.0:
		f_avail *= clampf((spec.top_speed_kmh / 3.6 - fs) / 3.0, 0.0, 1.0)
	elif drive_cmd < 0.0:
		f_avail *= 0.5 * clampf((8.0 + fs) / 2.0, 0.0, 1.0)
	var n_driven := 0
	for w in wheels:
		if w.driven: n_driven += 1
	var drive_per_wheel := (drive_cmd * f_avail) / maxf(1.0, float(n_driven))

	rear_grip_mod = move_toward(rear_grip_mod, 0.45 if handbrake_in else 1.0, (6.0 if handbrake_in else 1.5) * delta)

	var any_contact := false
	for i in 4:
		var w = wheels[i]
		var origin: Vector3 = to_global(w.mount)
		_ray.from = origin
		_ray.to = origin + down * (spec.susp_travel + spec.wheel_radius)
		_ray.exclude = [get_rid()]
		var hit := space.intersect_ray(_ray)
		if hit.is_empty():
			w.contact = false
			w.load_n = 0.0
			w.sliding = false
			w.slip = 0.0
			w.force_vec = Vector3.ZERO
			w.length = move_toward(w.length, spec.susp_travel, 1.5 * delta)
			w.prev_length = w.length
			continue
		any_contact = true
		var p: Vector3 = hit.position
		var n: Vector3 = hit.normal
		if n.dot(up) < 0.2:
			n = up
		var dist := origin.distance_to(p)
		var length := clampf(dist - spec.wheel_radius, 0.0, spec.susp_travel)
		var comp: float = spec.susp_travel - length
		var comp_vel := 0.0
		if w.contact:
			comp_vel = clampf((w.prev_length - length) / delta, -8.0, 8.0)
		w.prev_length = length
		w.length = length
		w.compression = comp
		w.contact = true
		w.point = p
		w.normal = n
		var fsp: float = w.spring_k * comp + w.spring_c * comp_vel
		fsp += w.spring_k * 6.0 * maxf(0.02 - length, 0.0)   # bump stop
		fsp = clampf(fsp, 0.0, spec.mass * GRAVITY * 4.0)
		w.load_n = fsp
		apply_force(n * fsp, p - global_position)

		var surf := 1.0
		var col = hit.collider
		if col != null and col.has_meta("grip"):
			surf = float(col.get_meta("grip"))

		var sa := 0.0
		if w.front:
			sa = steer_angle + toe_pull
		var yaw_dir: Vector3 = basis_g * Vector3(-sin(sa), 0.0, -cos(sa))
		var f: Vector3 = (yaw_dir - n * yaw_dir.dot(n)).normalized()
		var r: Vector3 = f.cross(n)
		var v := linear_velocity + angular_velocity.cross(p - com_g)
		var vlong := v.dot(f)
		var vlat := v.dot(r)
		w.vlong = vlong
		w.vlat = vlat

		var mu: float = spec.grip * surf * lerpf(0.65, 1.0, wheel_health[i])
		var mu_y := mu
		var brk: float = brake_cmd * spec.brake_force * (0.65 if w.front else 0.35)
		if not w.front:
			mu_y *= rear_grip_mod
			if handbrake_in:
				brk += spec.brake_force * 0.6
		var ss := clampf(vlong / 0.5, -1.0, 1.0)
		var fx: float = (drive_per_wheel if w.driven else 0.0)
		var brk_lim := spec.mass * 0.25 * absf(vlong) / delta * 0.8
		fx -= ss * minf(brk, brk_lim)
		fx -= ss * spec.rolling_res * w.load_n

		var ang := atan2(vlat, maxf(absf(vlong), 1.5))
		var sc := absf(ang) / 0.14
		var curve := sc if sc < 1.0 else lerpf(1.0, 0.72, clampf((sc - 1.0) / 2.5, 0.0, 1.0))
		var fy := -signf(ang) * curve * mu_y * w.load_n
		var fy_lim := spec.mass * 0.25 * absf(vlat) / delta * 0.8
		fy = clampf(fy, -fy_lim, fy_lim)

		var lim := maxf(mu * w.load_n, 1.0)
		var mag := Vector2(fx, fy).length()
		w.sliding = mag > lim * 0.98
		w.slip = mag / lim
		if mag > lim:
			fx *= lim / mag
			fy *= lim / mag
		var tf := f * fx + r * fy
		w.force_vec = tf
		apply_force(tf, p + n * spec.wheel_radius * 0.5 - global_position)

		if handbrake_in and not w.front:
			w.spin = w.spin   # rear wheels locked visually
		else:
			w.spin += vlong / spec.wheel_radius * delta
		if skid_marks != null and (w.sliding or (handbrake_in and not w.front)) and w.load_n > 300.0 and linear_velocity.length() > 4.0:
			if w.last_skid.distance_to(p) > 0.45:
				w.last_skid = p
				skid_marks.add_mark(p, f, n)

	# anti-roll bars (front pair, rear pair)
	for pair in [[0, 1], [2, 3]]:
		var a = wheels[pair[0]]
		var b = wheels[pair[1]]
		if a.contact and b.contact:
			var arf: float = (a.compression - b.compression) * a.spring_k * 0.5
			apply_force(up * arf, a.point - global_position)
			apply_force(-up * arf, b.point - global_position)

	# aerodynamic drag
	var vel := linear_velocity
	apply_central_force(-0.5 * AIR_DENSITY * spec.drag_cd * spec.frontal_area * vel.length() * vel)

	# air time / landing
	grounded = any_contact
	if not any_contact:
		air_time += delta
		_last_vy = linear_velocity.y
	else:
		if air_time > 0.4:
			var impact := absf(_last_vy)
			landed.emit(air_time, impact)
			if impact > 9.0:
				var d := clampf((impact - 9.0) * 0.06, 0.0, 0.5)
				_add_damage(Zones.WHEELS, d, Vector3.ZERO)
				_update_panel(Zones.WHEELS)
		air_time = 0.0

	var lv := basis_g.inverse() * linear_velocity
	if Vector2(lv.x, lv.z).length() > 6.0 and any_contact:
		drift_angle = absf(atan2(lv.x, -lv.z))
		if drift_angle > PI * 0.5:
			drift_angle = PI - drift_angle   # reversing
	else:
		drift_angle = 0.0
	_update_wheel_visuals()

# ---------------------------------------------------------------- damage
func _process_hits() -> void:
	if _pending_hits.is_empty():
		return
	var best := {}
	for h in _pending_hits:
		var z: int = h[0]
		if not best.has(z) or h[1] > best[z][1]:
			best[z] = h
	_pending_hits.clear()
	for z in best.keys():
		var h = best[z]
		var dmg := clampf((h[1] - HIT_THRESHOLD) * 0.045, 0.0, 0.6)
		_add_damage(z, dmg, h[2])
		_update_panel(z)
		var wp: Vector3 = to_global(h[2])
		_emit_sparks(wp, h[1])
		crashed.emit(z, h[1], wp)

func _add_damage(zone: int, dmg: float, lp: Vector3) -> void:
	if dmg <= 0.0:
		return
	zone_damage[zone] = minf(1.0, zone_damage[zone] + dmg)
	# neighbouring panels take part of the hit
	if zone == Zones.FRONT:
		zone_damage[Zones.HOOD] = minf(1.0, zone_damage[Zones.HOOD] + dmg * 0.4)
		_update_panel(Zones.HOOD)
	elif zone == Zones.REAR:
		zone_damage[Zones.TRUNK] = minf(1.0, zone_damage[Zones.TRUNK] + dmg * 0.4)
		_update_panel(Zones.TRUNK)
	# wheel / suspension damage
	if zone == Zones.WHEELS:
		for i in 4:
			wheel_health[i] = maxf(0.0, wheel_health[i] - dmg * 0.6)
	else:
		for i in 4:
			var m: Vector3 = wheels[i].mount
			if Vector2(m.x - lp.x, m.z - lp.z).length() < 0.9:
				wheel_health[i] = maxf(0.0, wheel_health[i] - dmg * 0.8)
	var wavg := (wheel_health[0] + wheel_health[1] + wheel_health[2] + wheel_health[3]) * 0.25
	zone_damage[Zones.WHEELS] = maxf(zone_damage[Zones.WHEELS], 1.0 - wavg)
	if not is_wrecked and damage_ratio() >= 1.0:
		is_wrecked = true
		wrecked.emit()
	_smoke.emitting = damage_ratio() > 0.55

func _emit_sparks(wp: Vector3, intensity: float) -> void:
	_sparks.global_position = wp
	_sparks.amount = int(clampf(intensity * 3.0, 6.0, 24.0) * particle_scale) + 1
	_sparks.restart()
	_sparks.emitting = true

func _update_panel(zone: int) -> void:
	if not panels.has(zone):
		return
	var d: float = zone_damage[zone]
	for m in panels[zone]:
		var rp: Vector3 = m.get_meta("rest_pos")
		var rs: Vector3 = m.get_meta("rest_scale")
		var ax: Vector3 = m.get_meta("crush_axis")
		var dirv: Vector3 = m.get_meta("crush_dir")
		var jit: Vector3 = m.get_meta("jitter")
		m.scale = rs * (Vector3.ONE - ax * 0.5 * d)           # bounded: max 50% squash
		m.position = rp + dirv * d * 0.12
		m.rotation = jit * d * 0.35
		var mat: StandardMaterial3D = m.material_override
		var base: Color = m.get_meta("base_color")
		mat.albedo_color = base.lerp(Color(0.1, 0.1, 0.1), d * 0.65)
		if d >= 0.999 and m.get_meta("detachable") and not m.get_meta("detached"):
			m.set_meta("detached", true)
			m.visible = false
			if debris_pool != null:
				var sz: Vector3 = (m.mesh as BoxMesh).size * m.scale
				debris_pool.spawn_piece(m.global_transform, sz, base, linear_velocity)

func _update_wheel_visuals() -> void:
	for i in 4:
		var w = wheels[i]
		if w.node == null:
			continue
		w.node.position = Vector3(w.mount.x, w.mount.y - w.length, w.mount.z)
		if w.front:
			w.node.rotation.y = -steer_cur * deg_to_rad(spec.max_steer_deg * 0.6)
		w.mesh_spin.rotation.x = -fposmod(w.spin, TAU)
