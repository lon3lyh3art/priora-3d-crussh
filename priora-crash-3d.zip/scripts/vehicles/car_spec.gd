extends Resource
## Per-car configuration. One .tres per car in res://data/cars/. Units: SI (kg, m, N, W, s).
## Values are approximate public figures / plausible tuning, NOT measured data.

@export var id: String = ""
@export var display_name: String = ""
@export var color: Color = Color.WHITE
@export var mass: float = 1200.0
@export var length: float = 4.4
@export var width: float = 1.7
@export var height: float = 1.45
@export var wheelbase: float = 2.55
@export var track: float = 1.45
@export var wheel_radius: float = 0.31
@export var cabin_len: float = 1.9
@export var cabin_z: float = 0.2
@export var trunk_ratio: float = 0.22
@export var front_weight: float = 0.55
@export var power_kw: float = 72.0
@export var max_accel: float = 4.0
@export var top_speed_kmh: float = 180.0
@export_enum("FWD", "RWD", "AWD") var drive: int = 0
@export var brake_force: float = 11000.0
@export var grip: float = 1.05
@export var susp_travel: float = 0.30
@export var susp_sag: float = 0.12
@export var damping_ratio: float = 0.45
@export var rolling_res: float = 0.015
@export var drag_cd: float = 0.34
@export var frontal_area: float = 2.0
@export var max_steer_deg: float = 33.0

func drive_name() -> String:
	return ["FWD", "RWD", "AWD"][drive]
