extends RefCounted
## Procedural placeholder body (box panels) with correct wheel mount points.
## These are NOT real car models; they are replaceable stand-ins.
const Zones = preload("res://scripts/vehicles/zones.gd")

static func _mat(color: Color, metal: float, rough: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.metallic = metal
	m.roughness = rough
	return m

static func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, metal := 0.5, rough := 0.4) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(color, metal, rough)
	mi.position = pos
	parent.add_child(mi)
	return mi

static func _panel(parent: Node3D, store: Dictionary, zone: int, size: Vector3, pos: Vector3,
		color: Color, axis: Vector3, inward: Vector3, detachable: bool) -> MeshInstance3D:
	var mi := _box(parent, size, pos, color)
	mi.set_meta("rest_pos", pos)
	mi.set_meta("rest_scale", Vector3.ONE)
	mi.set_meta("crush_axis", axis)
	mi.set_meta("crush_dir", inward)
	mi.set_meta("jitter", Vector3(randf_range(-1, 1), randf_range(-1, 1), randf_range(-1, 1)).normalized() * 0.6)
	mi.set_meta("base_color", color)
	mi.set_meta("detachable", detachable)
	mi.set_meta("detached", false)
	if not store.has(zone):
		store[zone] = []
	store[zone].append(mi)
	return mi

static func build(vehicle: RigidBody3D, spec, wheels: Array, body_offset: float) -> Dictionary:
	var store := {}
	var root := Node3D.new()
	root.name = "Body"
	root.position = Vector3(0, 0, body_offset)
	vehicle.add_child(root)
	var L: float = spec.length
	var W: float = spec.width
	var H: float = spec.height
	var hb := 0.52
	var base_y := 0.10
	var top := base_y + hb * 0.5
	var ground_to_origin: float = spec.susp_travel - spec.susp_sag + spec.wheel_radius
	var cab_h := maxf(0.45, H - (ground_to_origin + top))
	var col: Color = spec.color
	var core_len := L - 0.62
	_box(root, Vector3(W * 0.94, hb, core_len), Vector3(0, base_y, 0), col)
	var bump_c := col.darkened(0.15)
	var fb := _panel(root, store, Zones.FRONT, Vector3(W, hb * 0.7, 0.32), Vector3(0, base_y - 0.06, -(L * 0.5 - 0.16)), bump_c, Vector3(0, 0, 1), Vector3(0, 0, 0.5), true)
	_panel(root, store, Zones.REAR, Vector3(W, hb * 0.7, 0.32), Vector3(0, base_y - 0.06, L * 0.5 - 0.16), bump_c, Vector3(0, 0, 1), Vector3(0, 0, -0.5), true)
	# headlights / tail lights are children of the bumpers
	for sx in [-1.0, 1.0]:
		var hl := _box(fb, Vector3(0.28, 0.1, 0.04), Vector3(sx * W * 0.34, 0.12, -0.17), Color(1, 0.95, 0.75))
		(hl.material_override as StandardMaterial3D).emission_enabled = true
		(hl.material_override as StandardMaterial3D).emission = Color(1, 0.9, 0.6)
	var hood_len := core_len * 0.30
	var trunk_len := core_len * spec.trunk_ratio
	_panel(root, store, Zones.HOOD, Vector3(W * 0.92, 0.07, hood_len), Vector3(0, top + 0.035, -(L * 0.5 - 0.31 - hood_len * 0.5)), col, Vector3(0, 0.6, 0.6), Vector3(0, -0.3, 0.3), true)
	_panel(root, store, Zones.TRUNK, Vector3(W * 0.92, 0.07, trunk_len), Vector3(0, top + 0.035, L * 0.5 - 0.31 - trunk_len * 0.5), col, Vector3(0, 0.6, 0.6), Vector3(0, -0.3, -0.3), true)
	_panel(root, store, Zones.LEFT, Vector3(0.07, hb * 0.85, core_len * 0.55), Vector3(-(W * 0.47 + 0.02), base_y, 0), col, Vector3(1, 0, 0), Vector3(0.4, 0, 0), false)
	_panel(root, store, Zones.RIGHT, Vector3(0.07, hb * 0.85, core_len * 0.55), Vector3(W * 0.47 + 0.02, base_y, 0), col, Vector3(1, 0, 0), Vector3(-0.4, 0, 0), false)
	var cab_w := W * 0.84
	var cab_len: float = spec.cabin_len
	_box(root, Vector3(cab_w, cab_h, cab_len), Vector3(0, top + cab_h * 0.5, spec.cabin_z), Color(0.12, 0.17, 0.22), 0.7, 0.1)
	_panel(root, store, Zones.ROOF, Vector3(cab_w * 1.02, 0.06, cab_len * 1.02), Vector3(0, top + cab_h + 0.03, spec.cabin_z), col, Vector3(0, 1, 0), Vector3(0, -0.5, 0), false)
	# collision shapes (direct children of the body)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(W * 0.96, hb + 0.04, L - 0.1)
	cs.shape = bs
	cs.position = Vector3(0, base_y, body_offset)
	vehicle.add_child(cs)
	var cs2 := CollisionShape3D.new()
	var bs2 := BoxShape3D.new()
	bs2.size = Vector3(cab_w * 0.95, cab_h + 0.05, cab_len)
	cs2.shape = bs2
	cs2.position = Vector3(0, top + cab_h * 0.5, spec.cabin_z + body_offset)
	vehicle.add_child(cs2)
	# wheels
	var tire_mat := _mat(Color(0.07, 0.07, 0.07), 0.0, 0.9)
	var rim_mat := _mat(Color(0.65, 0.66, 0.7), 0.8, 0.35)
	var bar_mat := _mat(Color(0.9, 0.9, 0.9), 0.2, 0.5)
	for w in wheels:
		var node := Node3D.new()
		var spin := Node3D.new()
		node.add_child(spin)
		var tire := MeshInstance3D.new()
		var tm := CylinderMesh.new()
		tm.top_radius = spec.wheel_radius
		tm.bottom_radius = spec.wheel_radius
		tm.height = 0.2
		tm.radial_segments = 16
		tire.mesh = tm
		tire.material_override = tire_mat
		tire.rotation.z = PI * 0.5
		spin.add_child(tire)
		var rim := MeshInstance3D.new()
		var rm := CylinderMesh.new()
		rm.top_radius = spec.wheel_radius * 0.62
		rm.bottom_radius = spec.wheel_radius * 0.62
		rm.height = 0.205
		rm.radial_segments = 12
		rim.mesh = rm
		rim.material_override = rim_mat
		rim.rotation.z = PI * 0.5
		spin.add_child(rim)
		var side := 1.0 if w.mount.x > 0.0 else -1.0
		var bar := _box(spin, Vector3(0.02, spec.wheel_radius * 1.3, 0.06), Vector3(side * 0.105, 0, 0), Color.WHITE)
		bar.material_override = bar_mat
		node.position = Vector3(w.mount.x, -w.length, w.mount.z)
		vehicle.add_child(node)
		w.node = node
		w.mesh_spin = spin
	return {"panels": store}
