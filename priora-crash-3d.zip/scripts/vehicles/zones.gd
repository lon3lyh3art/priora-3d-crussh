extends RefCounted
## Damage zone ids shared by physics, visuals and HUD (plain ints, no class_name).
const FRONT := 0
const REAR := 1
const HOOD := 2
const TRUNK := 3
const LEFT := 4
const RIGHT := 5
const ROOF := 6
const WHEELS := 7
const COUNT := 8
## Share of each zone in total damage (sum = 1.0).
const WEIGHT := [0.18, 0.14, 0.12, 0.10, 0.12, 0.12, 0.08, 0.14]
const NAMES := ["Передний бампер", "Задний бампер", "Капот", "Багажник", "Левый борт", "Правый борт", "Крыша", "Колёса/подвеска"]
