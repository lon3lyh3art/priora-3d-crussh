extends Node
## Challenges: crash (score), speed (reach km/h), survive (limit damage). Records in user://records.cfg.
## finish() is guarded, so a challenge can never finish twice.
signal finished(id: String, win: bool, value: float, new_record: bool, text: String)
const PATH := "user://records.cfg"
const DEFS := {
	"crash": {"name": "Разрушитель: набери 2000 очков за 60 с", "limit": 60.0, "higher_better": true},
	"speed": {"name": "Разгон: достигни 150 км/ч за 40 с", "limit": 40.0, "higher_better": false},
	"surv": {"name": "Выживание: 90 с, урон меньше 50%", "limit": 90.0, "higher_better": true},
}
const ORDER := ["crash", "speed", "surv"]
var active_id: String = ""
var t_left: float = 0.0
var elapsed: float = 0.0
var records := {}

func _ready() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) == OK:
		for k in DEFS.keys():
			if cf.has_section_key("records", k):
				records[k] = float(cf.get_value("records", k))

func is_active() -> bool:
	return active_id != ""

func start(id: String) -> void:
	if not DEFS.has(id):
		return
	active_id = id
	t_left = DEFS[id]["limit"]
	elapsed = 0.0

func cancel() -> void:
	active_id = ""

func status_text() -> String:
	if active_id == "":
		return ""
	return "%s  |  %.1f с" % [DEFS[active_id]["name"].split(":")[0], maxf(0.0, t_left)]

func record_text(id: String) -> String:
	if not records.has(id):
		return ""
	var v: float = records[id]
	return (" — рекорд: %.1f с" % v) if id == "speed" else (" — рекорд: %d" % int(v))

func tick(delta: float, speed_kmh: float, damage_pct: float, score: int) -> void:
	if active_id == "":
		return
	t_left -= delta
	elapsed += delta
	match active_id:
		"crash":
			if score >= 2000:
				_finish(true, float(score))
			elif t_left <= 0.0:
				_finish(false, float(score))
		"speed":
			if speed_kmh >= 150.0:
				_finish(true, elapsed)
			elif t_left <= 0.0:
				_finish(false, elapsed)
		"surv":
			if damage_pct >= 50.0:
				_finish(false, 100.0 - damage_pct)
			elif t_left <= 0.0:
				_finish(true, 100.0 - damage_pct)

func _finish(win: bool, value: float) -> void:
	if active_id == "":
		return                      # guard against double finish
	var id := active_id
	active_id = ""
	var new_rec := false
	if win:
		var hb: bool = DEFS[id]["higher_better"]
		if not records.has(id) or (hb and value > records[id]) or (not hb and value < records[id]):
			records[id] = value
			new_rec = true
			var cf := ConfigFile.new()
			cf.load(PATH)
			cf.set_value("records", id, value)
			cf.save(PATH)
	var txt := ("Испытание пройдено" if win else "Не выполнено") + (" — новый рекорд!" if new_rec else "")
	finished.emit(id, win, value, new_rec, txt)
