extends Node
## Procedural audio (no asset files): engine via AudioStreamGenerator, crash via generated WAV.
## Not ported from the old version: tyre-squeal oscillator.
const RATE := 22050
var _engine: AudioStreamPlayer
var _pb: AudioStreamGeneratorPlayback
var _phase := 0.0
var _lp := 0.0
var _freq := 50.0
var _vol := 0.0
var _crash: Array = []
var _crash_i := 0
var _crash_stream: AudioStreamWAV

func _ready() -> void:
	var gen := AudioStreamGenerator.new()
	gen.mix_rate = RATE
	gen.buffer_length = 0.12
	_engine = AudioStreamPlayer.new()
	_engine.stream = gen
	_engine.volume_db = -6.0
	add_child(_engine)
	_engine.play()
	_pb = _engine.get_stream_playback() as AudioStreamGeneratorPlayback
	var n := 4410
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	for i in n:
		var env := pow(1.0 - float(i) / n, 2.0)
		bytes.encode_s16(i * 2, int((randf() * 2.0 - 1.0) * env * 30000.0))
	_crash_stream = AudioStreamWAV.new()
	_crash_stream.format = AudioStreamWAV.FORMAT_16_BITS
	_crash_stream.mix_rate = RATE
	_crash_stream.data = bytes
	for i in 3:
		var p := AudioStreamPlayer.new()
		p.stream = _crash_stream
		add_child(p)
		_crash.append(p)

func update_engine(speed_ms: float, throttle: float) -> void:
	_freq = 55.0 + speed_ms * 4.0
	_vol = 0.08 + throttle * 0.12 + minf(speed_ms, 40.0) * 0.002

func crash(intensity: float) -> void:
	var p: AudioStreamPlayer = _crash[_crash_i]
	_crash_i = (_crash_i + 1) % _crash.size()
	p.volume_db = linear_to_db(clampf(intensity * 0.06, 0.05, 0.9))
	p.play()

func _process(_d: float) -> void:
	if _pb == null:
		return
	var n := mini(_pb.get_frames_available(), 1500)
	if n <= 0:
		return
	var buf := PackedVector2Array()
	buf.resize(n)
	for i in n:
		_phase = fposmod(_phase + _freq / RATE, 1.0)
		var s := (_phase * 2.0 - 1.0) * 0.6 + (0.25 if fposmod(_phase * 2.0, 1.0) < 0.5 else -0.25)
		_lp = lerpf(_lp, s, 0.2)
		buf[i] = Vector2(_lp, _lp) * _vol
	_pb.push_buffer(buf)
