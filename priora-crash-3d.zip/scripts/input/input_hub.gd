extends Node
## Unified control source (autoload "Inp"): keyboard (InputMap) + touch buttons.
signal reset_pressed
signal camera_pressed
signal pause_pressed
signal debug_pressed
signal released_all

var held := {"left": false, "right": false, "gas": false, "brake": false, "hand": false}
var steer: float = 0.0   # -1 left .. +1 right (smoothed)

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_add_action("accelerate", [KEY_W, KEY_UP])
	_add_action("brake", [KEY_S, KEY_DOWN])
	_add_action("steer_left", [KEY_A, KEY_LEFT])
	_add_action("steer_right", [KEY_D, KEY_RIGHT])
	_add_action("handbrake", [KEY_SPACE])
	_add_action("reset_car", [KEY_R])
	_add_action("camera_toggle", [KEY_C])
	_add_action("pause", [KEY_ESCAPE, KEY_P])
	_add_action("debug_toggle", [KEY_F3])

func _add_action(action: String, keys: Array) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	for k in keys:
		var ev := InputEventKey.new()
		ev.physical_keycode = k
		InputMap.action_add_event(action, ev)

func set_button(btn_name: String, pressed: bool) -> void:
	if held.has(btn_name):
		held[btn_name] = pressed

func trigger(btn_name: String) -> void:
	match btn_name:
		"reset": reset_pressed.emit()
		"cam": camera_pressed.emit()
		"pause": pause_pressed.emit()

func release_all() -> void:
	for k in held.keys():
		held[k] = false
	steer = 0.0
	released_all.emit()

func get_throttle() -> float:
	return 1.0 if (held["gas"] or Input.is_action_pressed("accelerate")) else 0.0

func get_brake() -> float:
	return 1.0 if (held["brake"] or Input.is_action_pressed("brake")) else 0.0

func get_handbrake() -> bool:
	return held["hand"] or Input.is_action_pressed("handbrake")

func _process(delta: float) -> void:
	var l: bool = held["left"] or Input.is_action_pressed("steer_left")
	var r: bool = held["right"] or Input.is_action_pressed("steer_right")
	var target := (1.0 if r else 0.0) - (1.0 if l else 0.0)
	var rate := 7.0 if is_zero_approx(target) else 4.5 * Settings.steer_sensitivity
	steer = move_toward(steer, target, rate * delta)

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("reset_car"): reset_pressed.emit()
	elif event.is_action_pressed("camera_toggle"): camera_pressed.emit()
	elif event.is_action_pressed("pause"): pause_pressed.emit()
	elif event.is_action_pressed("debug_toggle"): debug_pressed.emit()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		release_all()
