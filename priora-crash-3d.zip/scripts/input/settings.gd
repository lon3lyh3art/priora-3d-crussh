extends Node
## Persistent user settings (autoload "Settings").
const PATH := "user://settings.cfg"
var steer_sensitivity: float = 1.0
var quality: int = 1          # 0 low, 1 medium, 2 high
var debug: bool = false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var cf := ConfigFile.new()
	if cf.load(PATH) == OK:
		steer_sensitivity = clampf(float(cf.get_value("input", "sensitivity", 1.0)), 0.5, 2.0)
		quality = clampi(int(cf.get_value("video", "quality", 1)), 0, 2)

func save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("input", "sensitivity", steer_sensitivity)
	cf.set_value("video", "quality", quality)
	cf.save(PATH)

## Safe-area margins in viewport units: x=left, y=top, z=right, w=bottom.
func safe_margins(vp: Vector2) -> Vector4:
	var win := Vector2(DisplayServer.window_get_size())
	var sa := DisplayServer.get_display_safe_area()
	if win.x <= 0.0 or win.y <= 0.0 or sa.size.x <= 0 or sa.size.y <= 0:
		return Vector4.ZERO
	var sc := vp.x / win.x
	var l := maxf(0.0, float(sa.position.x)) * sc
	var t := maxf(0.0, float(sa.position.y)) * sc
	var r := maxf(0.0, win.x - float(sa.position.x + sa.size.x)) * sc
	var b := maxf(0.0, win.y - float(sa.position.y + sa.size.y)) * sc
	return Vector4(l, t, r, b)
