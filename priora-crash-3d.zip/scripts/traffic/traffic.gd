extends Node3D
## Simple AI traffic: RigidBody3D cars that hold lane/speed with forces; when hit hard they
## become free bodies for a few seconds, then are teleported to the far end of the road.
const CRASH_DEVIATION := 5.0
const WRECK_TIME := 5.0
var bots: Array = []
var _body_mat: Array = []
var _glass_mat: StandardMaterial3D
var _body_mesh: BoxMesh
var _cab_mesh: BoxMesh

func spawn(count: int) -> void:
	clear()
	_glass_mat = StandardMaterial3D.new()
	_glass_mat.albedo_color = Color(0.13, 0.2, 0.27)
	_glass_mat.metallic = 0.6
	_glass_mat.roughness = 0.15
	_body_mesh = BoxMesh.new(); _body_mesh.size = Vector3(1.7, 0.6, 4.2)
	_cab_mesh = BoxMesh.new(); _cab_mesh.size = Vector3(1.5, 0.5, 2.0)
	for c in [0x3a6ea5, 0x8a3a3a, 0x3a8a5a, 0x8a7a3a, 0x6a4a8a]:
		var m := StandardMaterial3D.new()
		m.albedo_color = Color.hex((c << 8) | 0xff)
		m.metallic = 0.4
		m.roughness = 0.45
		_body_mat.append(m)
	var lane_speed := {-1: 11.0 + randf() * 3.0, 1: 11.0 + randf() * 3.0}
	for i in count:
		var dir := -1 if i % 2 == 0 else 1
		var slot := float(i / 2)
		var per_lane := ceili(count / 2.0)
		var z := -850.0 + (1700.0 / maxf(1.0, per_lane)) * slot + (40.0 if dir == 1 else 0.0)
		_add_bot(dir, z, lane_speed[dir], i)

func _add_bot(dir: int, z: float, speed: float, idx: int) -> void:
	var rb := RigidBody3D.new()
	rb.mass = 1100.0
	rb.collision_layer = 2
	rb.collision_mask = 3
	var pm := PhysicsMaterial.new()
	pm.friction = 0.4
	rb.physics_material_override = pm
	rb.center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	rb.center_of_mass = Vector3(0, -0.2, 0)
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.7, 0.9, 4.2)
	cs.shape = bs
	cs.position = Vector3(0, 0.1, 0)
	rb.add_child(cs)
	var body := MeshInstance3D.new()
	body.mesh = _body_mesh
	body.material_override = _body_mat[idx % _body_mat.size()]
	body.position = Vector3(0, 0.0, 0)
	rb.add_child(body)
	var cab := MeshInstance3D.new()
	cab.mesh = _cab_mesh
	cab.material_override = _glass_mat
	cab.position = Vector3(0, 0.55, 0.2)
	rb.add_child(cab)
	var lane_x := 3.5 if dir == -1 else -3.5
	rb.position = Vector3(lane_x, 0.75, z)
	rb.rotation.y = 0.0 if dir == -1 else PI
	rb.axis_lock_angular_x = true
	rb.axis_lock_angular_y = true
	rb.axis_lock_angular_z = true
	add_child(rb)
	bots.append({"rb": rb, "dir": dir, "speed": speed, "lane": lane_x, "crashed": false, "t": 0.0})

func clear() -> void:
	for b in bots:
		if is_instance_valid(b["rb"]):
			b["rb"].queue_free()
	bots.clear()

func _physics_process(delta: float) -> void:
	for b in bots:
		var rb: RigidBody3D = b["rb"]
		if not is_instance_valid(rb):
			continue
		var pos := rb.global_position
		if b["crashed"]:
			b["t"] -= delta
			if b["t"] <= 0.0 or pos.y < -10.0:
				_respawn(b)
			continue
		var v := rb.linear_velocity
		var tz: float = b["dir"] * b["speed"]
		var dev := Vector2(v.x, v.z - tz).length()
		if dev > CRASH_DEVIATION or absf(pos.x - b["lane"]) > 2.5:
			b["crashed"] = true
			b["t"] = WRECK_TIME
			rb.axis_lock_angular_x = false
			rb.axis_lock_angular_y = false
			rb.axis_lock_angular_z = false
			continue
		var fz := (tz - v.z) * 2200.0
		var fx := (b["lane"] - pos.x) * 3000.0 - v.x * 3000.0
		rb.apply_central_force(Vector3(fx, 0.0, fz))
		if (b["dir"] == -1 and pos.z < -900.0) or (b["dir"] == 1 and pos.z > 900.0):
			_teleport(rb, Vector3(b["lane"], 0.75, -b["dir"] * 880.0), b["dir"], b["speed"])

func _respawn(b: Dictionary) -> void:
	var rb: RigidBody3D = b["rb"]
	rb.axis_lock_angular_x = true
	rb.axis_lock_angular_y = true
	rb.axis_lock_angular_z = true
	b["crashed"] = false
	_teleport(rb, Vector3(b["lane"], 0.75, -b["dir"] * 880.0), b["dir"], b["speed"])

func _teleport(rb: RigidBody3D, p: Vector3, dir: int, speed: float) -> void:
	var xf := Transform3D(Basis(Vector3.UP, 0.0 if dir == -1 else PI), p)
	PhysicsServer3D.body_set_state(rb.get_rid(), PhysicsServer3D.BODY_STATE_TRANSFORM, xf)
	PhysicsServer3D.body_set_state(rb.get_rid(), PhysicsServer3D.BODY_STATE_LINEAR_VELOCITY, Vector3(0, 0, dir * speed))
	PhysicsServer3D.body_set_state(rb.get_rid(), PhysicsServer3D.BODY_STATE_ANGULAR_VELOCITY, Vector3.ZERO)
	rb.reset_physics_interpolation()
