extends Camera3D
## Chase / hood / far camera. Moves in _physics_process so engine physics interpolation smooths it.
var target: Node3D = null
var mode: int = 0
var shake: float = 0.0
var _heading := Vector3(0, 0, -1)

func snap() -> void:
	if target == null:
		return
	_heading = -target.global_transform.basis.z
	_heading.y = 0.0
	_heading = _heading.normalized()
	reset_physics_interpolation()
	_apply(1.0, 1.0)

func cycle_mode() -> void:
	mode = (mode + 1) % 3

func add_shake(a: float) -> void:
	shake = minf(0.5, maxf(shake, a))

func _physics_process(delta: float) -> void:
	_apply(1.0 - exp(-8.0 * delta), 1.0 - exp(-4.0 * delta))
	shake *= 0.85

func _apply(pos_k: float, head_k: float) -> void:
	if target == null or not is_instance_valid(target):
		return
	var xf := target.global_transform
	var tp := xf.origin
	if mode == 1:   # hood
		var p := xf * Vector3(0, 0.75, -0.2)
		global_transform = Transform3D(xf.basis, p)
		return
	var fwd := -xf.basis.z
	fwd.y = 0.0
	if fwd.length() > 0.01:
		_heading = _heading.lerp(fwd.normalized(), head_k).normalized()
	var back := 7.0 if mode == 0 else 13.0
	var h := 3.0 if mode == 0 else 6.5
	var want := tp - _heading * back + Vector3.UP * h
	global_position = global_position.lerp(want, pos_k)
	if shake > 0.01:
		global_position += Vector3(randf() - 0.5, randf() - 0.5, 0.0) * shake
	look_at(tp + Vector3.UP * 1.0 + _heading * 2.0, Vector3.UP)
