extends Node3D
## Builds the test proving ground procedurally. Static geometry uses MultiMesh chunks
## (distance-culled) and shared shapes; dynamic props are few and sleep when idle.
## Surface grip is read by the vehicle from the collider meta "grip".
const CHUNK := 450.0
var rng := RandomNumberGenerator.new()
var _mat_cache := {}

func build(quality: int) -> void:
	rng.seed = 20260527
	_ground()
	_roads()
	_markings()
	_curbs()
	_trees()
	_lamps()
	_buildings()
	_barriers()
	_ramps()
	_props(quality)
	_walls()
	_clouds()

# ---------------------------------------------------------------- helpers
func _mat(color: Color, rough := 0.9, emissive := false, vcol := false) -> StandardMaterial3D:
	var key := "%s_%s_%s_%s" % [color.to_html(), rough, emissive, vcol]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	if emissive:
		m.emission_enabled = true
		m.emission = color
	if vcol:
		m.vertex_color_use_as_albedo = true
	_mat_cache[key] = m
	return m

func _static_body(grip: float = 1.0) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.set_meta("grip", grip)
	add_child(sb)
	return sb

func _shape_box(body: Node3D, size: Vector3, pos: Vector3, rot_y := 0.0) -> void:
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	cs.position = pos
	cs.rotation.y = rot_y
	body.add_child(cs)

func _mesh_box(size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	return mi

## transforms: Array[Transform3D]; colors optional. Splits into z-chunks for culling.
func _multimesh(mesh: Mesh, mat: Material, transforms: Array, colors: Array = [], range_end := 520.0) -> void:
	var groups := {}
	for i in transforms.size():
		var c := int(floor((transforms[i].origin.z + 1000.0) / CHUNK))
		if not groups.has(c):
			groups[c] = []
		groups[c].append(i)
	for c in groups.keys():
		var idxs: Array = groups[c]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.use_colors = colors.size() > 0
		mm.mesh = mesh
		mm.instance_count = idxs.size()
		for k in idxs.size():
			mm.set_instance_transform(k, transforms[idxs[k]])
			if colors.size() > 0:
				mm.set_instance_color(k, colors[idxs[k]])
		var mi := MultiMeshInstance3D.new()
		mi.multimesh = mm
		mi.material_override = mat
		mi.visibility_range_end = range_end
		add_child(mi)

# ---------------------------------------------------------------- terrain
func _ground() -> void:
	var sb := _static_body(0.6)
	_shape_box(sb, Vector3(2000, 2, 2000), Vector3(0, -1, 0))
	var pm := PlaneMesh.new()
	pm.size = Vector2(2000, 2000)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = _mat(Color(0.42, 0.62, 0.30), 1.0)
	add_child(mi)
	# dirt arena (lower grip), x 40..170, z -420..-200
	var dirt := _static_body(0.7)
	_shape_box(dirt, Vector3(130, 0.2, 220), Vector3(105, -0.07, -310))
	_mesh_box(Vector3(130, 0.2, 220), Vector3(105, -0.07, -310), _mat(Color(0.45, 0.33, 0.2), 1.0))

func _roads() -> void:
	# [z_start, z_end, grip, colour]; wet patch has reduced grip
	var segs := [[-1000.0, -140.0, 1.0, Color(0.23, 0.23, 0.25)],
		[-140.0, -100.0, 0.55, Color(0.15, 0.18, 0.24)],
		[-100.0, 1000.0, 1.0, Color(0.23, 0.23, 0.25)]]
	for s in segs:
		var seg_len: float = s[1] - s[0]
		var zc: float = (s[0] + s[1]) * 0.5
		var sb := _static_body(s[2])
		_shape_box(sb, Vector3(24, 0.2, seg_len), Vector3(0, -0.08, zc))
		_mesh_box(Vector3(24, 0.2, seg_len), Vector3(0, -0.08, zc), _mat(s[3], 0.95 if s[2] >= 1.0 else 0.2))

func _markings() -> void:
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.3, 0.02, 5.0)
	var tf: Array = []
	for z in range(-960, 960, 12):
		tf.append(Transform3D(Basis.IDENTITY, Vector3(0, 0.025, z)))
	_multimesh(mesh, _mat(Color(0.94, 0.94, 0.85)), tf)
	for sx in [-11.5, 11.5]:
		_mesh_box(Vector3(0.25, 0.02, 2000), Vector3(sx, 0.025, 0), _mat(Color(0.94, 0.94, 0.85)))

func _curbs() -> void:
	var sb := _static_body(1.0)
	for sx in [-12.9, 12.9]:
		_shape_box(sb, Vector3(1.4, 0.2, 2000), Vector3(sx, 0.1, 0))
		_mesh_box(Vector3(1.4, 0.2, 2000), Vector3(sx, 0.1, 0), _mat(Color(0.6, 0.6, 0.62)))

func _trees() -> void:
	var trunk := CylinderMesh.new()
	trunk.top_radius = 0.25; trunk.bottom_radius = 0.35; trunk.height = 3.0; trunk.radial_segments = 6
	var crown := SphereMesh.new()
	crown.radius = 1.0; crown.height = 2.0; crown.radial_segments = 8; crown.rings = 4
	var tt: Array = []
	var ct: Array = []
	var sb := _static_body(1.0)
	for z in range(-880, 880, 26):
		for side in [-1, 1]:
			if rng.randf() < 0.7:
				var x: float = side * (17.0 + rng.randf() * 10.0)
				var zz: float = z + rng.randf() * 14.0
				var s := 1.8 + rng.randf() * 1.2
				tt.append(Transform3D(Basis.IDENTITY, Vector3(x, 1.5, zz)))
				ct.append(Transform3D(Basis.from_scale(Vector3(s, s * 1.15, s)), Vector3(x, 3.8, zz)))
				var cs := CollisionShape3D.new()
				var cyl := CylinderShape3D.new()
				cyl.radius = 0.5
				cyl.height = 3.0
				cs.shape = cyl
				cs.position = Vector3(x, 1.5, zz)
				sb.add_child(cs)
	_multimesh(trunk, _mat(Color(0.35, 0.25, 0.18)), tt)
	_multimesh(crown, _mat(Color(0.18, 0.49, 0.2)), ct)

func _lamps() -> void:
	var pole := CylinderMesh.new()
	pole.top_radius = 0.12; pole.bottom_radius = 0.15; pole.height = 7.0; pole.radial_segments = 6
	var head := SphereMesh.new()
	head.radius = 0.35; head.height = 0.7; head.radial_segments = 6; head.rings = 3
	var pt: Array = []
	var ht: Array = []
	var sb := _static_body(1.0)
	for z in range(-900, 900, 90):
		for side in [-1, 1]:
			var x: float = side * 14.5
			pt.append(Transform3D(Basis.IDENTITY, Vector3(x, 3.5, z)))
			ht.append(Transform3D(Basis.IDENTITY, Vector3(x - side * 0.7, 7.1, z)))
			_shape_box(sb, Vector3(0.4, 7.0, 0.4), Vector3(x, 3.5, z))
	_multimesh(pole, _mat(Color(0.33, 0.35, 0.38), 0.6), pt)
	_multimesh(head, _mat(Color(1.0, 0.91, 0.63), 0.5, true), ht)

func _buildings() -> void:
	var unit := BoxMesh.new()
	unit.size = Vector3.ONE
	var palette := [Color(0.78, 0.74, 0.66), Color(0.58, 0.6, 0.64), Color(0.62, 0.36, 0.3), Color(0.45, 0.52, 0.6), Color(0.7, 0.7, 0.7)]
	var tf: Array = []
	var cols: Array = []
	var sb := _static_body(1.0)
	for side in [-1, 1]:
		var z := -900.0
		while z < 900.0:
			var w := 14.0 + rng.randf() * 12.0
			var d := 18.0 + rng.randf() * 12.0
			var h := 8.0 + rng.randf() * 22.0
			var x: float = side * (48.0 + w * 0.5 + rng.randf() * 18.0)
			tf.append(Transform3D(Basis.from_scale(Vector3(w, h, d)), Vector3(x, h * 0.5, z + d * 0.5)))
			cols.append(palette[rng.randi() % palette.size()])
			_shape_box(sb, Vector3(w, h, d), Vector3(x, h * 0.5, z + d * 0.5))
			z += d + 8.0 + rng.randf() * 14.0
	_multimesh(unit, _mat(Color.WHITE, 0.9, false, true), tf, cols, 650.0)

func _barriers() -> void:
	var bm := BoxMesh.new()
	bm.size = Vector3(0.6, 0.8, 3.0)
	var tf: Array = []
	var sb := _static_body(1.0)
	for i in 20:
		for sx in [-11.0, 11.0]:
			var p := Vector3(sx, 0.4, -520.0 + i * 3.05)
			tf.append(Transform3D(Basis.IDENTITY, p))
			_shape_box(sb, bm.size, p)
	for i in 6:     # slalom blocks
		var p := Vector3(-4.0 if i % 2 == 0 else 4.0, 0.4, -380.0 + i * 25.0)
		tf.append(Transform3D(Basis.IDENTITY, p))
		_shape_box(sb, bm.size, p)
	_multimesh(bm, _mat(Color(0.72, 0.72, 0.7)), tf)

func _make_wedge(w: float, h: float, l: float) -> Array:
	var P := [Vector3(-w / 2, 0, 0), Vector3(w / 2, 0, 0), Vector3(-w / 2, 0, l), Vector3(w / 2, 0, l),
		Vector3(-w / 2, h, l), Vector3(w / 2, h, l)]
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var tris := [
		[0, 1, 5, Vector3(0, l, -h)], [0, 5, 4, Vector3(0, l, -h)],         # slope
		[2, 4, 5, Vector3(0, 0, 1)], [2, 5, 3, Vector3(0, 0, 1)],            # back wall
		[0, 2, 3, Vector3(0, -1, 0)], [0, 3, 1, Vector3(0, -1, 0)],          # bottom
		[0, 4, 2, Vector3(-1, 0, 0)], [1, 3, 5, Vector3(1, 0, 0)]]           # sides
	for t in tris:
		var a: Vector3 = P[t[0]]
		var b: Vector3 = P[t[1]]
		var c: Vector3 = P[t[2]]
		var n: Vector3 = (t[3] as Vector3).normalized()
		if (b - a).cross(c - a).dot(n) > 0.0:     # Godot front faces are clockwise
			var tmp := b
			b = c
			c = tmp
		for v in [a, b, c]:
			st.set_normal(n)
			st.add_vertex(v)
	var mesh := st.commit()
	var shape := ConvexPolygonShape3D.new()
	shape.points = PackedVector3Array(P)
	return [mesh, shape]

func _ramp(pos: Vector3, yaw: float, w: float, h: float, l: float, color: Color) -> void:
	var r := _make_wedge(w, h, l)
	var sb := _static_body(1.0)
	sb.position = pos
	sb.rotation.y = yaw
	var cs := CollisionShape3D.new()
	cs.shape = r[1]
	sb.add_child(cs)
	var mi := MeshInstance3D.new()
	mi.mesh = r[0]
	mi.material_override = _mat(color, 0.8)
	sb.add_child(mi)

func _ramps() -> void:
	# rise towards -Z needs yaw PI (wedge rises towards local +Z)
	_ramp(Vector3(3.5, 0.0, -230.0), PI, 6.0, 1.6, 9.0, Color(0.85, 0.55, 0.1))
	_ramp(Vector3(0.0, 0.0, -620.0), PI, 10.0, 3.0, 18.0, Color(0.8, 0.3, 0.1))
	_ramp(Vector3(-3.5, 0.0, 250.0), 0.0, 6.0, 1.6, 9.0, Color(0.85, 0.55, 0.1))
	_ramp(Vector3(80.0, 0.03, -250.0), PI, 7.0, 2.0, 11.0, Color(0.6, 0.6, 0.65))
	_ramp(Vector3(130.0, 0.03, -380.0), PI * 0.5, 7.0, 2.0, 11.0, Color(0.6, 0.6, 0.65))

func _props(quality: int) -> void:
	var bm := BoxMesh.new()
	bm.size = Vector3(0.9, 0.9, 0.9)
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.3; cyl.bottom_radius = 0.3; cyl.height = 0.9; cyl.radial_segments = 8
	var box_mat := _mat(Color(0.72, 0.5, 0.25), 0.8)
	var bar_mat := _mat(Color(0.8, 0.15, 0.1), 0.5)
	# wall of crates on the right lane at z=-420
	for ix in 4:
		for iy in 3:
			_dyn(bm, box_mat, Vector3(3.5 - 1.8 + ix * 0.95, 0.46 + iy * 0.92, -420.0), 25.0, false)
	# pyramids in the dirt arena
	for p in 3:
		var cx := 60.0 + p * 30.0
		for row in 4:
			for k in (4 - row):
				_dyn(bm, box_mat, Vector3(cx + (k - (3 - row) * 0.5) * 0.95, 0.46 + row * 0.92, -300.0), 25.0, false)
	# barrels
	var nb := 8 + quality * 6
	for i in nb:
		_dyn(cyl, bar_mat, Vector3(-8.0 + rng.randf() * 4.0, 0.46, -160.0 - i * 2.2), 30.0, true)

func _dyn(mesh: Mesh, mat: Material, pos: Vector3, m: float, cylinder: bool) -> void:
	var rb := RigidBody3D.new()
	rb.mass = m
	rb.collision_layer = 2
	rb.collision_mask = 3
	rb.position = pos
	var cs := CollisionShape3D.new()
	if cylinder:
		var c := CylinderShape3D.new()
		c.radius = 0.3
		c.height = 0.9
		cs.shape = c
	else:
		var b := BoxShape3D.new()
		b.size = Vector3(0.9, 0.9, 0.9)
		cs.shape = b
	rb.add_child(cs)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	rb.add_child(mi)
	add_child(rb)

func _walls() -> void:
	var sb := _static_body(1.0)
	_shape_box(sb, Vector3(400, 30, 3), Vector3(0, 10, -992))
	_shape_box(sb, Vector3(400, 30, 3), Vector3(0, 10, 992))
	_shape_box(sb, Vector3(3, 30, 2000), Vector3(-196, 10, 0))
	_shape_box(sb, Vector3(3, 30, 2000), Vector3(196, 10, 0))

func _clouds() -> void:
	var sm := SphereMesh.new()
	sm.radius = 1.0; sm.height = 2.0; sm.radial_segments = 8; sm.rings = 4
	var tf: Array = []
	for i in 24:
		var s := 14.0 + rng.randf() * 14.0
		tf.append(Transform3D(Basis.from_scale(Vector3(s, s * 0.35, s * 0.7)),
			Vector3((rng.randf() - 0.5) * 500.0, 90.0 + rng.randf() * 40.0, (rng.randf() - 0.5) * 1800.0)))
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1, 1, 1)
	_multimesh(sm, m, tf, [], 900.0)
