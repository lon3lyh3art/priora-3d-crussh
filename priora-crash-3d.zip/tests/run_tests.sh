#!/usr/bin/env bash
# Usage: GODOT=/path/to/godot ./tests/run_tests.sh
set -euo pipefail
GODOT="${GODOT:-godot}"
cd "$(dirname "$0")/.."
"$GODOT" --headless --path . --import
"$GODOT" --headless --path . -s tests/smoke_test.gd
