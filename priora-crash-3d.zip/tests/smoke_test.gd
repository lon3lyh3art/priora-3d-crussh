extends SceneTree
## Headless smoke/physics test.
## Run:  godot --headless --path . -s tests/smoke_test.gd
## Exit code 0 = all checks passed.
const CAR_IDS := ["priora", "priora_hatch", "vesta", "granta", "kalina", "largus", "vaz2107", "vaz2106", "vaz2114", "niva"]
const VehicleScene = preload("res://scenes/vehicles/vehicle.tscn")
var failures := 0
var checks := 0

func check(cond: bool, msg: String) -> void:
	checks += 1
	if cond:
		print("  PASS  ", msg)
	else:
		failures += 1
		printerr("  FAIL  ", msg)

func _frames(n: int) -> void:
	for i in n:
		await physics_frame

func _finite(v: Vector3) -> bool:
	return is_finite(v.x) and is_finite(v.y) and is_finite(v.z)

func _initialize() -> void:
	await _run()
	print("== %d checks, %d failures ==" % [checks, failures])
	quit(1 if failures > 0 else 0)

func _ensure_autoloads() -> void:
	if not root.has_node("Settings"):
		var s = load("res://scripts/input/settings.gd").new()
		s.name = "Settings"
		root.add_child(s)
	if not root.has_node("Inp"):
		var i = load("res://scripts/input/input_hub.gd").new()
		i.name = "Inp"
		root.add_child(i)

func _make_floor(parent: Node) -> StaticBody3D:
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(2000, 2, 2000)
	cs.shape = bs
	cs.position = Vector3(0, -1, 0)
	sb.add_child(cs)
	parent.add_child(sb)
	return sb

func _run() -> void:
	_ensure_autoloads()
	print("[1] resources")
	var specs := {}
	for id in CAR_IDS:
		var path := "res://data/cars/%s.tres" % id
		check(ResourceLoader.exists(path), "exists " + path)
		var s = load(path)
		specs[id] = s
		check(s != null and s.mass > 500.0 and s.wheelbase > 2.0 and s.power_kw > 10.0, "spec sane " + id)
	check(root.has_node("Inp") and root.has_node("Settings"), "autoloads present")
	for a in ["accelerate", "brake", "steer_left", "steer_right", "handbrake", "reset_car", "camera_toggle", "pause"]:
		check(InputMap.has_action(a), "InputMap action " + a)

	print("[2] vehicle on flat floor")
	var scene := Node3D.new()
	root.add_child(scene)
	_make_floor(scene)
	var v = VehicleScene.instantiate()
	v.setup(specs["priora"])
	v.transform = Transform3D(Basis.IDENTITY, Vector3(0, 0.7, 0))
	scene.add_child(v)
	await _frames(240)
	check(v.wheels.size() == 4, "four wheels")
	var contacts := 0
	for w in v.wheels:
		if w.contact: contacts += 1
	check(contacts == 4, "all four wheels in contact (got %d)" % contacts)
	check(v.linear_velocity.length() < 0.2, "no phantom acceleration at rest (v=%.3f)" % v.linear_velocity.length())
	check(_finite(v.global_position) and _finite(v.linear_velocity), "state finite at rest")
	var rest_h := v.global_position.y
	check(rest_h > 0.3 and rest_h < 0.8, "ride height plausible (%.2f m)" % rest_h)

	print("[3] acceleration / braking / steering")
	v.set_controls(1.0, 0.0, 0.0, false)
	await _frames(360)
	var sp1: float = v.speed_kmh()
	check(sp1 > 25.0, "accelerates (%.1f km/h after 3 s)" % sp1)
	check(v.linear_velocity.dot(-v.global_transform.basis.z) > 0.0, "moves forward (-Z)")
	check(absf(v.global_position.x) < 2.0, "tracks straight (x=%.2f)" % v.global_position.x)
	v.set_controls(0.0, 1.0, 0.0, false)
	await _frames(300)
	check(v.speed_kmh() < sp1 * 0.3, "brakes (%.1f km/h)" % v.speed_kmh())
	await _frames(240)
	check(v.speed_kmh() < 3.0, "stops and does not creep (%.2f km/h)" % v.speed_kmh())
	v.set_controls(1.0, 0.0, 1.0, false)
	await _frames(240)
	var yaw_rate: float = absf(v.angular_velocity.y)
	check(yaw_rate > 0.05, "steering turns the car (yaw rate %.2f)" % yaw_rate)
	check(_finite(v.global_position) and _finite(v.linear_velocity) and _finite(v.angular_velocity), "state finite after manoeuvres")

	print("[4] collision, damage, reset")
	v.reset_upright(true)
	await _frames(120)
	var wall := StaticBody3D.new()
	var wcs := CollisionShape3D.new()
	var wbs := BoxShape3D.new()
	wbs.size = Vector3(20, 5, 1)
	wcs.shape = wbs
	wall.add_child(wcs)
	var fwd: Vector3 = -v.global_transform.basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	scene.add_child(wall)
	wall.global_transform = Transform3D(v.global_transform.basis.orthonormalized(), v.global_position + fwd * 40.0 + Vector3(0, 2.5, 0))
	v.set_controls(1.0, 0.0, 0.0, false)
	await _frames(1500)
	check(v.damage_percent() > 1.0, "crash causes damage (%.1f%%)" % v.damage_percent())
	check(_finite(v.global_position), "state finite after crash")
	v.set_controls(0.0, 0.0, 0.0, false)
	v.reset_upright(true)
	await _frames(60)
	check(v.damage_percent() == 0.0, "reset repairs damage")
	check(v.global_transform.basis.y.y > 0.9, "reset leaves car upright")

	print("[5] all cars load and settle")
	for id in CAR_IDS:
		var c = VehicleScene.instantiate()
		c.setup(specs[id])
		c.transform = Transform3D(Basis.IDENTITY, Vector3(100, 0.7, 100))
		scene.add_child(c)
		await _frames(180)
		var n := 0
		for w in c.wheels:
			if w.contact: n += 1
		check(n == 4 and c.linear_velocity.length() < 0.3 and _finite(c.global_position), "car %s settles (contacts=%d)" % [id, n])
		c.queue_free()
		await _frames(2)

	print("[6] main scene / car switching")
	scene.queue_free()
	await _frames(2)
	var main = load("res://scenes/main/main.tscn").instantiate()
	root.add_child(main)
	await _frames(30)
	check(main.vehicle != null, "main scene spawns a vehicle")
	for id in CAR_IDS:
		main.spawn_vehicle(id)
		await _frames(5)
		check(main.vehicle != null and main.car_id == id and main.vehicle.wheels.size() == 4, "switch to " + id)
	check(Inp.get_throttle() == 0.0, "no stuck input after start")
	Inp.set_button("gas", true)
	Inp.set_button("right", true)
	check(Inp.get_throttle() == 1.0, "touch gas registers")
	Inp.release_all()
	check(Inp.get_throttle() == 0.0 and not Inp.held["right"], "release_all clears buttons")
	main.challenges.start("crash")
	main.challenges.cancel()
	main.challenges.start("surv")
	await _frames(5)
	check(main.challenges.is_active(), "challenge starts")
