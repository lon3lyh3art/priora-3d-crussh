#!/usr/bin/env python3
"""Generates data/cars/*.tres. Re-run after editing the table. Figures are approximate."""
import os
# id, name, colour, mass, L, W, H, wheelbase, kW, topkmh, drive(0 FWD,1 RWD,2 AWD), wheelR, cabin_len, cabin_z, trunk_ratio, front_w, cd, area
CARS = [
 ("priora",       "ВАЗ-2170 «Приора»",          0xb01e23, 1200, 4.35, 1.68, 1.42, 2.49, 72, 185, 0, 0.30, 1.90, 0.25, 0.24, 0.57, 0.33, 1.95),
 ("priora_hatch", "ВАЗ-2172 «Приора» хэтчбек",  0x1c1c1e, 1190, 4.21, 1.68, 1.44, 2.49, 72, 185, 0, 0.30, 2.10, 0.45, 0.10, 0.57, 0.34, 1.97),
 ("vesta",        "LADA Vesta",                  0xc47b2a, 1280, 4.41, 1.76, 1.50, 2.63, 78, 185, 0, 0.32, 1.95, 0.20, 0.23, 0.56, 0.32, 2.10),
 ("granta",       "LADA Granta",                 0xe8e8ea, 1170, 4.27, 1.70, 1.50, 2.47, 64, 170, 0, 0.30, 1.80, 0.25, 0.24, 0.57, 0.34, 2.00),
 ("kalina",       "LADA Kalina",                 0x3a9b6b, 1100, 3.89, 1.70, 1.50, 2.47, 64, 170, 0, 0.30, 1.85, 0.35, 0.10, 0.57, 0.35, 2.00),
 ("largus",       "LADA Largus",                 0xd8dde2, 1350, 4.47, 1.75, 1.64, 2.91, 77, 165, 0, 0.31, 2.60, 0.45, 0.04, 0.55, 0.37, 2.35),
 ("vaz2107",      "ВАЗ-2107 «Семёрка»",          0x2a5fa8, 1060, 4.14, 1.62, 1.44, 2.42, 54, 150, 1, 0.29, 1.75, 0.15, 0.26, 0.54, 0.45, 1.90),
 ("vaz2106",      "ВАЗ-2106 «Шестёрка»",         0x6b8f3a, 1050, 4.17, 1.61, 1.44, 2.42, 55, 155, 1, 0.29, 1.70, 0.15, 0.26, 0.54, 0.46, 1.90),
 ("vaz2114",      "ВАЗ-2114 «Девятка»",          0x7a1f8a,  990, 4.12, 1.65, 1.50, 2.46, 60, 165, 0, 0.29, 2.00, 0.40, 0.10, 0.58, 0.37, 1.95),
 ("niva",         "LADA Niva Legend",            0x3a6b35, 1250, 3.74, 1.68, 1.64, 2.20, 61, 135, 2, 0.34, 1.90, 0.30, 0.08, 0.52, 0.55, 2.30),
]
out = os.path.join(os.path.dirname(__file__), "..", "data", "cars")
os.makedirs(out, exist_ok=True)
for (cid, name, col, m, L, W, H, wb, kw, top, drv, wr, cl, cz, tr, fw, cd, area) in CARS:
    r, g, b = ((col >> 16) & 255) / 255.0, ((col >> 8) & 255) / 255.0, (col & 255) / 255.0
    susp = 0.34 if cid == "niva" else 0.30
    grip = 1.0 if cid in ("vaz2107", "vaz2106") else 1.05
    txt = f'''[gd_resource type="Resource" script_class="CarSpec" load_steps=2 format=3]

[ext_resource type="Script" path="res://scripts/vehicles/car_spec.gd" id="1_spec"]

[resource]
script = ExtResource("1_spec")
id = "{cid}"
display_name = "{name}"
color = Color({r:.4f}, {g:.4f}, {b:.4f}, 1)
mass = {float(m)}
length = {L}
width = {W}
height = {H}
wheelbase = {wb}
track = {round(W-0.22,3)}
wheel_radius = {wr}
cabin_len = {cl}
cabin_z = {cz}
trunk_ratio = {tr}
front_weight = {fw}
power_kw = {float(kw)}
max_accel = {4.6 if drv==2 else 4.0}
top_speed_kmh = {float(top)}
drive = {drv}
brake_force = {round(m*9.0,1)}
grip = {grip}
susp_travel = {susp}
susp_sag = 0.12
damping_ratio = 0.45
rolling_res = 0.015
drag_cd = {cd}
frontal_area = {area}
max_steer_deg = 33.0
'''
    with open(os.path.join(out, cid + ".tres"), "w", encoding="utf-8") as f:
        f.write(txt)
print("ok", len(CARS))
