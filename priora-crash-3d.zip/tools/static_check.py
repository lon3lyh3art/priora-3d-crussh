#!/usr/bin/env python3
"""Static checks that work without Godot: res:// references exist, brackets balance,
indentation does not mix tabs/spaces, preload() targets exist, class/extends present.
This is NOT a GDScript compiler; it catches only gross mistakes."""
import os, re, sys
root = os.path.join(os.path.dirname(__file__), "..")
errors = []
def rp(p): return os.path.join(root, p.replace("res://", ""))
for dp, _, fs in os.walk(root):
    if any(x in dp for x in (".git", ".godot", "legacy")): continue
    for f in fs:
        path = os.path.join(dp, f)
        rel = os.path.relpath(path, root)
        if not f.endswith((".gd", ".tscn", ".tres", ".godot", ".cfg", ".yml")): continue
        txt = open(path, encoding="utf-8").read()
        for m in re.finditer(r'res://[A-Za-z0-9_./-]+', txt):
            if not os.path.exists(rp(m.group(0))): errors.append(f"{rel}: missing {m.group(0)}")
        if f.endswith(".gd"):
            depth = {"(": 0, "[": 0, "{": 0}; pair = {")": "(", "]": "[", "}": "{"}
            for ln, line in enumerate(txt.splitlines(), 1):
                code = re.sub(r'"(\\.|[^"\\])*"', '""', line).split("#")[0]
                lead = line[:len(line) - len(line.lstrip())]
                if "\t" in lead and " " in lead: errors.append(f"{rel}:{ln}: mixed indentation")
                for ch in code:
                    if ch in depth: depth[ch] += 1
                    elif ch in pair: depth[pair[ch]] -= 1
            if any(depth.values()): errors.append(f"{rel}: unbalanced brackets {depth}")
            if not re.search(r'^extends\s', txt, re.M): errors.append(f"{rel}: no extends")
print("\n".join(errors) if errors else "static_check: OK")
sys.exit(1 if errors else 0)
